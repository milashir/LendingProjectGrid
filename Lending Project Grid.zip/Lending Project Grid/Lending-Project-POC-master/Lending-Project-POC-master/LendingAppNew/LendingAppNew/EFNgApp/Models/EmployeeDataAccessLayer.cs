﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public class EmployeeDataAccessLayer
    {
        //To Get the list of Employees  
        public List<EmployeeModel> GetEmployees()
        {
            List<EmployeeModel> lstEmployee = new List<EmployeeModel>();
            EmployeeModel employee1 = new EmployeeModel();
            employee1.id=1;
            employee1.firstname="aa";
            employee1.middlename="bb";
            employee1.lastname="cc";
            employee1.gender="Male";
            employee1.dob=DateTime.Now;
            employee1.streetaddress1="dd";
            employee1.streetaddress2="ee";
            employee1.country=1;
            employee1.state=1;
            employee1.city=1;
            employee1.zip="22222";
            employee1.selectedskills="Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee1);
            EmployeeModel employee2 = new EmployeeModel();
            employee2.id = 2;
            employee2.firstname = "aa1";
            employee2.middlename = "bb1";
            employee2.lastname = "cc1";
            employee2.gender = "Female";
            employee2.dob = DateTime.Now.AddDays(1);
            employee2.streetaddress1 = "dd1";
            employee2.streetaddress2 = "ee1";
            employee2.country = 2;
            employee2.state = 3;
            employee2.city = 3;
            employee2.zip = "22222";
            employee2.selectedskills = "Sql Server";
            lstEmployee.Add(employee2);

            EmployeeModel employee3 = new EmployeeModel();
            employee3.id = 1;
            employee3.firstname = "aa";
            employee3.middlename = "bb";
            employee3.lastname = "cc";
            employee3.gender = "Male";
            employee3.dob = DateTime.Now;
            employee3.streetaddress1 = "dd";
            employee3.streetaddress2 = "ee";
            employee3.country = 1;
            employee3.state = 1;
            employee3.city = 1;
            employee3.zip = "22222";
            employee3.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee3);

            EmployeeModel employee4 = new EmployeeModel();
            employee4.id = 1;
            employee4.firstname = "aa";
            employee1.middlename = "bb";
            employee4.lastname = "cc";
            employee4.gender = "Male";
            employee4.dob = DateTime.Now;
            employee4.streetaddress1 = "dd";
            employee4.streetaddress2 = "ee";
            employee4.country = 1;
            employee4.state = 1;
            employee4.city = 1;
            employee4.zip = "22222";
            employee4.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee4);

            EmployeeModel employee5 = new EmployeeModel();
            employee5.id = 1;
            employee5.firstname = "aa";
            employee5.middlename = "bb";
            employee5.lastname = "cc";
            employee5.gender = "Male";
            employee5.dob = DateTime.Now;
            employee5.streetaddress1 = "dd";
            employee5.streetaddress2 = "ee";
            employee5.country = 1;
            employee5.state = 1;
            employee5.city = 1;
            employee5.zip = "22222";
            employee5.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee5);

            EmployeeModel employee6 = new EmployeeModel();
            employee6.id = 1;
            employee6.firstname = "aa";
            employee6.middlename = "bb";
            employee6.lastname = "cc";
            employee6.gender = "Male";
            employee6.dob = DateTime.Now;
            employee6.streetaddress1 = "dd";
            employee6.streetaddress2 = "ee";
            employee6.country = 1;
            employee6.state = 1;
            employee6.city = 1;
            employee6.zip = "22222";
            employee6.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee6);

            EmployeeModel employee7 = new EmployeeModel();
            employee7.id = 1;
            employee7.firstname = "aa";
            employee7.middlename = "bb";
            employee7.lastname = "cc";
            employee7.gender = "Male";
            employee7.dob = DateTime.Now;
            employee7.streetaddress1 = "dd";
            employee7.streetaddress2 = "ee";
            employee7.country = 1;
            employee7.state = 1;
            employee7.city = 1;
            employee7.zip = "22222";
            employee7.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee7);

            EmployeeModel employee8 = new EmployeeModel();
            employee8.id = 1;
            employee8.firstname = "aa";
            employee8.middlename = "bb";
            employee8.lastname = "cc";
            employee1.gender = "Male";
            employee8.dob = DateTime.Now;
            employee8.streetaddress1 = "dd";
            employee8.streetaddress2 = "ee";
            employee8.country = 1;
            employee8.state = 1;
            employee8.city = 1;
            employee8.zip = "22222";
            employee8.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee8);

            EmployeeModel employee9 = new EmployeeModel();
            employee9.id = 1;
            employee9.firstname = "aa";
            employee9.middlename = "bb";
            employee9.lastname = "cc";
            employee9.gender = "Male";
            employee9.dob = DateTime.Now;
            employee9.streetaddress1 = "dd";
            employee9.streetaddress2 = "ee";
            employee9.country = 1;
            employee9.state = 1;
            employee9.city = 1;
            employee9.zip = "22222";
            employee9.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee9);

            EmployeeModel employee10 = new EmployeeModel();
            employee10.id = 1;
            employee10.firstname = "aa";
            employee10.middlename = "bb";
            employee10.lastname = "cc";
            employee10.gender = "Male";
            employee10.dob = DateTime.Now;
            employee10.streetaddress1 = "dd";
            employee10.streetaddress2 = "ee";
            employee10.country = 1;
            employee10.state = 1;
            employee10.city = 1;
            employee10.zip = "22222";
            employee10.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee10);

            EmployeeModel employee11 = new EmployeeModel();
            employee11.id = 1;
            employee11.firstname = "aa";
            employee11.middlename = "bb";
            employee11.lastname = "cc";
            employee11.gender = "Male";
            employee11.dob = DateTime.Now;
            employee11.streetaddress1 = "dd";
            employee11.streetaddress2 = "ee";
            employee11.country = 1;
            employee11.state = 1;
            employee11.city = 1;
            employee11.zip = "22222";
            employee11.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee11);

            EmployeeModel employee12 = new EmployeeModel();
            employee12.id = 1;
            employee12.firstname = "aa";
            employee12.middlename = "bb";
            employee12.lastname = "cc";
            employee12.gender = "Male";
            employee12.dob = DateTime.Now;
            employee12.streetaddress1 = "dd";
            employee12.streetaddress2 = "ee";
            employee12.country = 1;
            employee12.state = 1;
            employee12.city = 1;
            employee12.zip = "22222";
            employee12.selectedskills = "Asp.Net,C#,Sql Server,JavaScript";
            lstEmployee.Add(employee12);
            return lstEmployee;
        }

        //To Get the list of Employees  
        public EmployeeModel GetEmployeeById(int id)
        {
            List<EmployeeModel> lstEmployee = GetEmployees();            
            return lstEmployee.Where(x=>x.id==id).ToList().FirstOrDefault();
        }

        //To Get the list of Country  
        public List<TblCountry> GetCountrys()
        {
            List<TblCountry> lstCountry = new List<TblCountry>();
            TblCountry country1 = new TblCountry();
            country1.countryid = 1;
            country1.countryname = "India";
            lstCountry.Add(country1);
            TblCountry country2 = new TblCountry();
            country2.countryid = 2;
            country2.countryname = "Germany";
            lstCountry.Add(country2);
            return lstCountry;
        }


        //To Get the list of Cities  
        public List<TblCities> GetCities()
        {
            List<TblCities> lstCity = new List<TblCities>();
            TblCities city1 = new TblCities();
            city1.cityid = 1;
            city1.cityname = "Calicut";
            city1.stateid = 1;
            lstCity.Add(city1);
            TblCities city2 = new TblCities();
            city2.cityid = 2;
            city2.cityname = "Cochin";
            city2.stateid = 1;
            lstCity.Add(city2);
            TblCities city3 = new TblCities();
            city3.cityid = 3;
            city3.cityname = "Berlin";
            city3.stateid = 3;
            lstCity.Add(city3);
            TblCities city4 = new TblCities();
            city4.cityid = 4;
            city4.cityname = "Munich";
            city4.stateid = 4;
            lstCity.Add(city4);
            return lstCity;
        }

        //To Get the list of States  
        public List<TblState> GetStates()
        {
            List<TblState> lstState = new List<TblState>();
            TblState state1 = new TblState();
            state1.stateid = 1;
            state1.statename = "Kerala";
            state1.countryid = 1;
            lstState.Add(state1);
            TblState state2 = new TblState();
            state2.stateid = 2;
            state2.statename = "Karnataka";
            state2.countryid = 1;
            lstState.Add(state2);
            TblState state3 = new TblState();
            state1.stateid = 3;
            state1.statename = "Berlin";
            state1.countryid = 2;
            lstState.Add(state3);
            TblState state4 = new TblState();
            state2.stateid = 4;
            state2.statename = "Bremen";
            state2.countryid = 2;
            lstState.Add(state4);
            return lstState;
        }


        //To Get the list of States by country  
        public List<TblState> GetStateByCountry(int countryId)
        {
            List<TblState> lstState = new List<TblState>();
            TblState state1 = new TblState();
            state1.stateid = 1;
            state1.statename = "Kerala";
            state1.countryid = 1;
            lstState.Add(state1);
            TblState state2 = new TblState();
            state2.stateid = 2;
            state2.statename = "Karnataka";
            state2.countryid = 1;
            lstState.Add(state2);
            TblState state3 = new TblState();
            state3.stateid = 3;
            state3.statename = "Berlin";
            state3.countryid = 2;
            lstState.Add(state3);
            TblState state4 = new TblState();
            state4.stateid = 4;
            state4.statename = "Bremen";
            state4.countryid = 2;
            lstState.Add(state4);
            return lstState.Where(x => x.countryid == countryId).ToList();
        }

        //To Get the list of Cities by state  
        public List<TblCities> GetCityByState(int stateId)
        {            
            List<TblCities> lstCity = new List<TblCities>();
            TblCities city1 = new TblCities();
            city1.cityid = 1;
            city1.cityname = "Calicut";
            city1.stateid = 1;
            city1.countryid = 1;
            lstCity.Add(city1);
            TblCities city2 = new TblCities();
            city2.cityid = 2;
            city2.cityname = "Cochin";
            city2.stateid = 1;
            city2.countryid = 1;
            lstCity.Add(city2);
            TblCities city3 = new TblCities();
            city3.cityid = 3;
            city3.cityname = "Berlin";
            city3.stateid = 3;
            city3.countryid = 2;
            lstCity.Add(city3);
            TblCities city4 = new TblCities();
            city4.cityid = 4;
            city4.cityname = "Munich";
            city4.stateid = 4;
            city4.countryid = 2;
            lstCity.Add(city4);
            return lstCity.Where(x=>x.stateid==stateId).ToList();
        }

        public void SaveEmployee(EmployeeModel employee)
        {
            if (employee.id > 0)
            {
            }
            else
            {
            }
        }
    }
}
