﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public partial class TblCountry
    {
        public int countryid { get; set; }
        public string countryname { get; set; }
    }
}
