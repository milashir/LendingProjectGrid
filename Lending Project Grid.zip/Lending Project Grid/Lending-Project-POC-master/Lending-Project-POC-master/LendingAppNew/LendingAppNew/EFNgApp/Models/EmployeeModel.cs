﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFNgApp.Models
{
    public partial class EmployeeModel
    {
        public int id;
        public string firstname;
        public string middlename;
        public string lastname;
        public string gender;
        public DateTime dob;
        public string streetaddress1;
        public string streetaddress2;
        public int country;
        public int state;
        public int city;
        public string zip;
        public string selectedskills;
        public List<TblCountry> countryList = new List<TblCountry>();
        public List<TblState> stateList = new List<TblState>();
        public List<TblCities> cityList = new List<TblCities>();
    }

    public class Skill
    {
        public string skill;
    }
}
