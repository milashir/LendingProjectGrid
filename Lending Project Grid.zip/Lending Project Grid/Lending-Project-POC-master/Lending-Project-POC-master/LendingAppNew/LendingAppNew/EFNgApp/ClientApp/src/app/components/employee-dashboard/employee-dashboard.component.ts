import { Component, Inject } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../../services/employeeservice.service';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent {
  public employeeList: employeeData[];

  columnDefs = [
    { headerName: 'First Name', field: 'firstname' },
    { headerName: 'Middle Name', field: 'middlename' },
    { headerName: 'Lat Name', field: 'lastname' }
  ];

  //rowData = [
  //  { make: 'Toyota', model: 'Celica', price: 35000 },
  //  { make: 'Ford', model: 'Mondeo', price: 32000 },
  //  { make: 'Porsche', model: 'Boxter', price: 72000, editable: true }
  //];

  constructor(public http: Http, private _router: Router, private _employeeService: EmployeeService) {
    this.getEmployees();
  }

  getEmployees() {
    this._employeeService.getEmployees().subscribe(
      data => this.employeeList = data
    )
  }
}

interface employeeData {
  firstname: string;
  middlename: string;
  lastname: string;
  gender: string;
  dob: string;
  streetaddress1: string;
  streetaddress2: string;
  country: string;
  state: string;
  city: string;
  zip: string;
  selectedskills: string;
}



