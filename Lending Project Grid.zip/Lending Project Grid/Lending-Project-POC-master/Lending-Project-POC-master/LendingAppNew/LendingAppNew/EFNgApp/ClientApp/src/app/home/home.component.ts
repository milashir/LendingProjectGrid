import { Component, Inject } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { JobService } from '../services/jobservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {
  public interestingJobsList: interestingJobsData[];

  constructor(public http: Http, private _router: Router, private _jobService: JobService) {
    //this.getEmployees();
    this.getInterestingJobs();
  }

  //getEmployees() {
  //  this._employeeService.getEmployees().subscribe(
  //    data => this.employeeList = data
  //  )
 // }

  getInterestingJobs() {
  this._jobService.getInterestingJobs().subscribe(
    data => this.interestingJobsList = data
    )
  }
}

//interface employeeData {
//  firstname: string;
//  middlename: string;
//  lastname: string;
//  gender: string;
//  dob: string;
//  streetaddress1: string;
//  streetaddress2: string;
//  country: string;
//  state: string;
//  city: string;
//  zip: string;
//  selectedskills: string;
//}

interface interestingJobsData {
  id: number;
  position: string;
  company: string;
  companyimage: string;
  jobposted: string;
  location: string
}
